Universe generic-LaTeX source package for author/referee review.
Build: latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
Use full TeX Live or MiKTeX with Latin Modern and natbib.
Author declarations, archive DOI and provenance decisions remain TODO.
Not an author-approved submission; raw survey data are not included.
SHA256.json identifies exact included source and PDF bytes.
